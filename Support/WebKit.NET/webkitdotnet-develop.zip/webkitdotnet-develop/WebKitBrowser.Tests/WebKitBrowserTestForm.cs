﻿using System.Windows.Forms;

namespace WebKit.Tests
{
    public partial class WebKitBrowserTestForm : Form
    {
        public WebKitBrowserTestForm()
        {
            InitializeComponent();
        }
    }
}
